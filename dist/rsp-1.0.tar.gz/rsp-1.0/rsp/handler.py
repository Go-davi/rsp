CHOICE_LIST = ['r','s','p']


def get_user_choice():
    pass