from setuptools import setup

setup(
    name = 'rsp',
    version = '1.0',
    packages = ['rsp'],
    zip_self = False,

)